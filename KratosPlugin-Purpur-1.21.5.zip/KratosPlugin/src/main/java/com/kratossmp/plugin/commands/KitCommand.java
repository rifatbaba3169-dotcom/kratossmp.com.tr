package com.kratossmp.plugin.commands;

import com.kratossmp.plugin.managers.KitManager;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class KitCommand implements CommandExecutor {
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();
    private final KitManager manager;

    public KitCommand(KitManager manager) {
        this.manager = manager;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player p)) return true;
        String cmd = command.getName().toLowerCase();

        switch (cmd) {
            case "kitolustur" -> {
                if (!p.hasPermission("kit.admin")) { p.sendMessage(LEGACY.deserialize("&cYetkin yok!")); return true; }
                if (args.length < 2) { p.sendMessage(LEGACY.deserialize("&c/kitoluştur <isim> <saniye>")); return true; }
                try {
                    int sec = Integer.parseInt(args[1]);
                    manager.createKit(p, args[0], sec);
                } catch (NumberFormatException e) {
                    p.sendMessage(LEGACY.deserialize("&cGeçersiz saniye değeri!"));
                }
            }
            case "kitsil" -> {
                if (!p.hasPermission("kit.admin")) { p.sendMessage(LEGACY.deserialize("&cYetkin yok!")); return true; }
                if (args.length < 1) { p.sendMessage(LEGACY.deserialize("&c/kitsil <isim>")); return true; }
                manager.deleteKit(p, args[0]);
            }
            case "kitduzelt" -> {
                if (!p.hasPermission("kit.admin")) { p.sendMessage(LEGACY.deserialize("&cYetkin yok!")); return true; }
                manager.fixKits(p);
            }
            case "adminkitolustur" -> {
                if (!p.hasPermission("kit.admin")) { p.sendMessage(LEGACY.deserialize("&cYetkin yok!")); return true; }
                manager.createAdminKit(p);
            }
            case "kit" -> {
                if (args.length > 0) {
                    manager.giveKit(p, args[0].toLowerCase());
                } else {
                    if (manager.getKitList().isEmpty()) {
                        p.sendMessage(LEGACY.deserialize("&8[&6Kit&8] &cHenüz hiç kit yok."));
                        return true;
                    }
                    manager.openMenu(p);
                }
            }
        }
        return true;
    }
}
