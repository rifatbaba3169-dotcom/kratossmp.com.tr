package com.kratossmp.plugin.commands;

import com.kratossmp.plugin.managers.KratosToolManager;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class KratosToolCommand implements CommandExecutor {
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();
    private final KratosToolManager manager;

    public KratosToolCommand(KratosToolManager manager) {
        this.manager = manager;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (args.length == 0) {
            if (sender instanceof ConsoleCommandSender) {
                sender.sendMessage("Konsoldan kullanım: /kratosalet <kazma|ipekkazma|balta|kurek|cubuk> <oyuncu>");
                return true;
            }
            if (!(sender instanceof Player p) || !p.isOp()) {
                sender.sendMessage(LEGACY.deserialize("&cBu komutu sadece OP'ler kullanabilir!"));
                return true;
            }
            manager.openAdminMenu(p);
            return true;
        }

        if (!(sender instanceof ConsoleCommandSender)) {
            sender.sendMessage(LEGACY.deserialize("&cBu komut sadece menüyü açar: /kratosalet"));
            return true;
        }

        if (args.length < 2) {
            sender.sendMessage("Kullanım: /kratosalet <kazma|ipekkazma|balta|kurek|cubuk> <oyuncu>");
            return true;
        }

        Player target = Bukkit.getPlayer(args[1]);
        if (target == null || !target.isOnline()) return true;

        String type = args[0].toLowerCase();
        switch (type) {
            case "kazma", "ipekkazma", "balta", "kurek", "cubuk" -> {
                manager.giveItem(target, manager.createTool(type));
                target.sendMessage(LEGACY.deserialize("&cKratos aleti &7verildi."));
            }
            default -> sender.sendMessage("Geçersiz tür! kazma, ipekkazma, balta, kurek, cubuk");
        }
        return true;
    }
}
