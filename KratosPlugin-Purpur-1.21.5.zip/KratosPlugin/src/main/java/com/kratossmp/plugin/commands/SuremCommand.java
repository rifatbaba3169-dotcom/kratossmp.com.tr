package com.kratossmp.plugin.commands;

import com.kratossmp.plugin.tasks.OnlineRewardTask;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class SuremCommand implements CommandExecutor {
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();
    private final OnlineRewardTask task;

    public SuremCommand(OnlineRewardTask task) {
        this.task = task;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) return true;
        int kalan = task.getRemainingSeconds(player.getUniqueId());
        int dk = kalan / 60;
        int sn = kalan % 60;
        player.sendMessage(LEGACY.deserialize("&a[Sunucu] &fKasa ödülüne kalan süren: &e" + dk + " dakika " + sn + " saniye"));
        return true;
    }
}
