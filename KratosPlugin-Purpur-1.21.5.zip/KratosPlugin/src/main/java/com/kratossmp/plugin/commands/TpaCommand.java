package com.kratossmp.plugin.commands;

import com.kratossmp.plugin.KratosPlugin;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class TpaCommand implements CommandExecutor {
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();
    private final Map<UUID, UUID> tpaRequest = new HashMap<>();
    private final Map<UUID, String> tpaType = new HashMap<>();
    private final Map<UUID, UUID> tpaSent = new HashMap<>();
    private final Map<UUID, String> tpaMode = new HashMap<>();
    private final Map<UUID, String> tpahereMode = new HashMap<>();

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) return true;
        String cmd = command.getName().toLowerCase();
        UUID uuid = player.getUniqueId();

        switch (cmd) {
            case "tpauto" -> {
                String m = tpaMode.getOrDefault(uuid, "on").equals("auto") ? "on" : "auto";
                tpaMode.put(uuid, m);
                player.sendMessage(LEGACY.deserialize(m.equals("auto") ? "&e&l[TPA] &aOtomatik TPA alma modu açıldı!" : "&e&l[TPA] &cOtomatik TPA alma modu kapatıldı!"));
                return true;
            }
            case "tpahereauto" -> {
                String m = tpahereMode.getOrDefault(uuid, "on").equals("auto") ? "on" : "auto";
                tpahereMode.put(uuid, m);
                player.sendMessage(LEGACY.deserialize(m.equals("auto") ? "&e&l[TPA] &aOtomatik TPA Here kabul etme modu açıldı!" : "&e&l[TPA] &cOtomatik TPA Here kabul etme modu kapatıldı!"));
                return true;
            }
            case "tpaoff" -> {
                tpaMode.put(uuid, "off");
                tpahereMode.put(uuid, "off");
                player.sendMessage(LEGACY.deserialize("&e&l[TPA] &cTüm TPA ve TPA Here istekleri kapatıldı!"));
                return true;
            }
            case "tpaon" -> {
                tpaMode.put(uuid, "on");
                tpahereMode.put(uuid, "on");
                player.sendMessage(LEGACY.deserialize("&e&l[TPA] &aTüm TPA ve TPA Here istekleri açıldı!"));
                return true;
            }
            case "tpa" -> {
                if (args.length == 0) {
                    player.sendMessage(LEGACY.deserialize("&cKullanım: /tpa <oyuncu>"));
                    return true;
                }
                if (args[0].equalsIgnoreCase("accept")) {
                    UUID req = tpaRequest.remove(uuid);
                    String type = tpaType.remove(uuid);
                    if (req == null) {
                        player.sendMessage(LEGACY.deserialize("&cSana gelen aktif bir TPA/TPAHere isteği yok!"));
                        return true;
                    }
                    Player target = Bukkit.getPlayer(req);
                    if (target != null) tpaSent.remove(target.getUniqueId());
                    player.sendMessage(LEGACY.deserialize("&a&l[TPA] &eİstek kabul edildi!"));
                    if (target != null && target.isOnline()) {
                        if ("tpa".equals(type)) startTeleport(target, player);
                        else if ("tpahere".equals(type)) startTeleport(player, target);
                    }
                    return true;
                }
                if (args[0].equalsIgnoreCase("deny")) {
                    UUID req = tpaRequest.remove(uuid);
                    tpaType.remove(uuid);
                    if (req == null) {
                        player.sendMessage(LEGACY.deserialize("&cSana gelen aktif bir TPA isteği yok!"));
                        return true;
                    }
                    Player target = Bukkit.getPlayer(req);
                    if (target != null) {
                        tpaSent.remove(target.getUniqueId());
                        target.sendMessage(LEGACY.deserialize("&c&l[TPA] &e" + player.getName() + " &caışınlanma isteğinizi reddetti."));
                        player.sendMessage(LEGACY.deserialize("&c&l[TPA] &e" + target.getName() + " &cadlı oyuncunun isteği reddedildi."));
                    }
                    return true;
                }
                if (args[0].equalsIgnoreCase("cancel")) {
                    UUID sent = tpaSent.remove(uuid);
                    if (sent == null) {
                        player.sendMessage(LEGACY.deserialize("&cAktif olarak kimseye attığınız bir TPA isteği yok!"));
                        return true;
                    }
                    Player target = Bukkit.getPlayer(sent);
                    if (target != null) {
                        tpaRequest.remove(target.getUniqueId());
                        tpaType.remove(target.getUniqueId());
                        target.sendMessage(LEGACY.deserialize("&e&l[TPA] &b" + player.getName() + " &cgönderdiği ışınlanma isteğini iptal etti."));
                    }
                    player.sendMessage(LEGACY.deserialize("&e&l[TPA] &cIşınlanma isteğinizi iptal ettiniz."));
                    return true;
                }
                Player target = Bukkit.getPlayer(args[0]);
                if (target == null || !target.isOnline()) {
                    player.sendMessage(LEGACY.deserialize("&c'" + args[0] + "' adında aktif bir oyuncu bulunamadı!"));
                    return true;
                }
                if (target.equals(player)) {
                    player.sendMessage(LEGACY.deserialize("&cKendi kendine ışınlanamazsın!"));
                    return true;
                }
                String mode = tpaMode.getOrDefault(target.getUniqueId(), "on");
                if (mode.equals("off")) {
                    player.sendMessage(LEGACY.deserialize("&c&l[TPA] &e" + target.getName() + " &cşu anda TPA isteklerini tamamen kapatmış."));
                    return true;
                }
                if (mode.equals("auto")) {
                    player.sendMessage(LEGACY.deserialize("&a&l[TPA] &e" + target.getName() + " &aOtomatik TPA modunda!"));
                    target.sendMessage(LEGACY.deserialize("&a&l[TPA] &e" + player.getName() + " &aotomatik olarak yanınıza ışınlanıyor..."));
                    startTeleport(player, target);
                    return true;
                }
                tpaRequest.put(target.getUniqueId(), uuid);
                tpaType.put(target.getUniqueId(), "tpa");
                tpaSent.put(uuid, target.getUniqueId());
                player.sendMessage(LEGACY.deserialize("&e&l[TPA] &b" + target.getName() + " &eadlı oyuncuya ışınlanma isteği gönderildi."));
                sendClickableRequest(target, "&e&l[TPA] &b" + player.getName() + " &esize bir ışınlanma isteği gönderdi!");
                return true;
            }
            case "tpahere" -> {
                if (args.length == 0) {
                    player.sendMessage(LEGACY.deserialize("&cKullanım: /tpahere <oyuncu>"));
                    return true;
                }
                Player target = Bukkit.getPlayer(args[0]);
                if (target == null || !target.isOnline()) {
                    player.sendMessage(LEGACY.deserialize("&c'" + args[0] + "' adında aktif bir oyuncu bulunamadı!"));
                    return true;
                }
                if (target.equals(player)) {
                    player.sendMessage(LEGACY.deserialize("&cKendi kendini yanına çağıramazsın!"));
                    return true;
                }
                String mode = tpahereMode.getOrDefault(target.getUniqueId(), "on");
                if (mode.equals("off")) {
                    player.sendMessage(LEGACY.deserialize("&c&l[TPA] &e" + target.getName() + " &cşu anda TPA Here isteklerini kapatmış."));
                    return true;
                }
                if (mode.equals("auto")) {
                    player.sendMessage(LEGACY.deserialize("&a&l[TPA] &e" + target.getName() + " &aOtomatik TPA Here modunda! Yanınıza ışınlanıyor..."));
                    target.sendMessage(LEGACY.deserialize("&a&l[TPA] &e" + player.getName() + " &asizi yanına çağırıyor, ışınlanma başlatıldı..."));
                    startTeleport(target, player);
                    return true;
                }
                tpaRequest.put(target.getUniqueId(), uuid);
                tpaType.put(target.getUniqueId(), "tpahere");
                tpaSent.put(uuid, target.getUniqueId());
                player.sendMessage(LEGACY.deserialize("&e&l[TPA] &b" + target.getName() + " &eadlı oyuncuya yanınıza gelme isteği gönderildi."));
                sendClickableRequest(target, "&e&l[TPA] &b" + player.getName() + " &esizi yanına çağırıyor!");
                return true;
            }
        }
        return true;
    }

    private void sendClickableRequest(Player target, String header) {
        target.sendMessage(LEGACY.deserialize(""));
        target.sendMessage(LEGACY.deserialize(header));
        target.sendMessage(MiniMessage.miniMessage().deserialize("<click:run_command:'/tpa accept'><green><b>[ KABUL ET ]</b></green></click>  <click:run_command:'/tpa deny'><red><b>[ REDDET ]</b></red></click>"));
        target.sendMessage(LEGACY.deserialize("&7(Veya komutla: /tpa accept &7| &7/tpa deny)"));
        target.sendMessage(LEGACY.deserialize(""));
        target.playSound(target.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1.0f, 2.0f);
    }

    private void startTeleport(Player p, Player dest) {
        Location startLoc = p.getLocation().clone();
        p.sendMessage(LEGACY.deserialize("&e&l[TPA] &aIşınlanma 3 saniye içinde gerçekleşecek. Lütfen hareket etmeyin!"));
        for (int i = 0; i < 3; i++) {
            final int sec = 3 - i;
            final float pitch = 1.0f + (i * 0.25f);
            Bukkit.getScheduler().runTaskLater(KratosPlugin.getInstance(), () -> {
                if (!p.isOnline()) return;
                if (p.getLocation().distanceSquared(startLoc) > 0.25) return;
                p.sendMessage(LEGACY.deserialize("&e&l[TPA] &f" + sec + "..."));
                p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1.0f, pitch);
            }, i * 20L);
        }
        Bukkit.getScheduler().runTaskLater(KratosPlugin.getInstance(), () -> {
            if (!p.isOnline() || !dest.isOnline()) return;
            if (p.getLocation().distanceSquared(startLoc) > 0.25) {
                p.sendMessage(LEGACY.deserialize("&c&l[TPA] &cHareket ettiğiniz için ışınlanma iptal edildi!"));
                return;
            }
            p.teleport(dest);
            p.playSound(p.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1.0f, 1.0f);
            dest.playSound(dest.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1.0f, 1.0f);
            p.sendMessage(LEGACY.deserialize("&a&l[TPA] &aBaşarıyla ışınlandınız!"));
        }, 60L);
    }
}
