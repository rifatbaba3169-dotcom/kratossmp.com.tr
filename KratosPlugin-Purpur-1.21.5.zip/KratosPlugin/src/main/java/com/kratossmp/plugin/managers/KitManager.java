package com.kratossmp.plugin.managers;

import com.kratossmp.plugin.KratosPlugin;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class KitManager {
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();
    private final KratosPlugin plugin;
    private final File file;
    private YamlConfiguration data;

    public final Map<UUID, Map<Integer, String>> openMenus = new HashMap<>();

    public KitManager(KratosPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "kits.yml");
        if (!file.exists()) {
            try { file.createNewFile(); } catch (IOException ignored) {}
        }
        this.data = YamlConfiguration.loadConfiguration(file);
    }

    public void saveKits() {
        try { data.save(file); } catch (IOException ignored) {}
    }

    public List<String> getKitList() {
        return data.getStringList("kitlist");
    }

    public boolean kitExists(String name) {
        return data.getBoolean("kits." + name.toLowerCase() + ".var", false);
    }

    public void createKit(Player p, String rawName, int seconds) {
        String n = rawName.toLowerCase(Locale.ROOT);
        int maxKit = plugin.getConfig().getInt("kit.max-kit", 6);
        if (seconds < 0) {
            p.sendMessage(LEGACY.deserialize("&8[&6Kit&8] &cSaniye 0 veya daha büyük olmalı!"));
            return;
        }
        if (kitExists(n)) {
            p.sendMessage(LEGACY.deserialize("&8[&6Kit&8] &cBu isimde bir kit zaten var!"));
            return;
        }
        List<String> list = new ArrayList<>(getKitList());
        if (list.size() >= maxKit) {
            p.sendMessage(LEGACY.deserialize("&8[&6Kit&8] &cEn fazla " + maxKit + " kit olabilir! Önce &e/kitsil &cile birini sil."));
            return;
        }
        int count = 0;
        for (int i = 0; i <= 40; i++) {
            ItemStack it = p.getInventory().getItem(i);
            if (it != null && it.getType() != Material.AIR) {
                data.set("kits." + n + ".items." + i, it.clone());
                count++;
            }
        }
        if (count == 0) {
            p.sendMessage(LEGACY.deserialize("&8[&6Kit&8] &cEnvanterin, elin ve zırhın boş, kit oluşturulamadı!"));
            return;
        }
        data.set("kits." + n + ".var", true);
        data.set("kits." + n + ".cd", seconds);
        list.add(n);
        data.set("kitlist", list);
        saveKits();
        p.sendMessage(LEGACY.deserialize("&8[&6Kit&8] &a&l" + n + " &akiti oluşturuldu! &7(" + count + " eşya, bekleme: " + seconds + " saniye)"));
    }

    public void deleteKit(Player p, String rawName) {
        String n = rawName.toLowerCase(Locale.ROOT);
        List<String> list = new ArrayList<>(getKitList());
        if (!kitExists(n) && !list.contains(n)) {
            p.sendMessage(LEGACY.deserialize("&8[&6Kit&8] &cBöyle bir kit yok!"));
            return;
        }
        data.set("kits." + n, null);
        list.removeIf(s -> s.equalsIgnoreCase(n));
        data.set("kitlist", list);
        saveKits();
        p.sendMessage(LEGACY.deserialize("&8[&6Kit&8] &e" + n + " &7kiti silindi."));
    }

    public void fixKits(Player p) {
        List<String> list = getKitList();
        List<String> clean = new ArrayList<>();
        int removed = 0;
        for (String k : list) {
            if (kitExists(k)) {
                if (!clean.contains(k)) clean.add(k);
            } else {
                data.set("kits." + k, null);
                removed++;
            }
        }
        data.set("kitlist", clean);
        saveKits();
        p.sendMessage(LEGACY.deserialize("&8[&6Kit&8] &a" + removed + " bozuk kit temizlendi. Kalan kit: &e" + clean.size()));
    }

    public void createAdminKit(Player p) {
        String source = null;
        for (String k : getKitList()) {
            if (k.contains("bilgili")) { source = k; break; }
        }
        if (source == null) {
            p.sendMessage(LEGACY.deserialize("&8[&6Kit&8] &cBilgili kiti bulunamadı! Önce bilgili kitini oluştur."));
            return;
        }
        List<String> list = new ArrayList<>(getKitList());
        int maxKit = plugin.getConfig().getInt("kit.max-kit", 6);
        if (!kitExists("adminkiti") && list.size() >= maxKit) {
            p.sendMessage(LEGACY.deserialize("&8[&6Kit&8] &cEn fazla " + maxKit + " kit olabilir!"));
            return;
        }
        data.set("kits.adminkiti", null);
        if (!list.contains("adminkiti")) list.add("adminkiti");
        data.set("kitlist", list);

        ConfigurationSection sec = data.getConfigurationSection("kits." + source + ".items");
        int count = 0;
        if (sec != null) {
            for (String key : sec.getKeys(false)) {
                ItemStack it = sec.getItemStack(key);
                if (it != null) {
                    data.set("kits.adminkiti.items." + key, convertNetherite(it.clone()));
                    count++;
                }
            }
        }
        data.set("kits.adminkiti.cd", data.getInt("kits." + source + ".cd", 0));
        data.set("kits.adminkiti.var", true);
        saveKits();
        p.sendMessage(LEGACY.deserialize("&8[&6Kit&8] &a&ladminkiti &akiti oluşturuldu! &7(" + count + " eşya, kaynak: " + source + ", hepsi netherite)"));
    }

    private ItemStack convertNetherite(ItemStack it) {
        String typeName = it.getType().name();
        if (typeName.startsWith("NETHERITE_")) return it;
        String[] parts = {"SWORD", "PICKAXE", "AXE", "SHOVEL", "HOE", "HELMET", "CHESTPLATE", "LEGGINGS", "BOOTS"};
        for (String part : parts) {
            if (typeName.endsWith("_" + part)) {
                Material mat = Material.getMaterial("NETHERITE_" + part);
                if (mat != null) {
                    ItemStack nItem = new ItemStack(mat, it.getAmount());
                    ItemMeta oldMeta = it.getItemMeta();
                    ItemMeta newMeta = nItem.getItemMeta();
                    if (oldMeta != null && newMeta != null) {
                        if (oldMeta.hasDisplayName()) newMeta.displayName(oldMeta.displayName());
                        for (Map.Entry<Enchantment, Integer> e : oldMeta.getEnchants().entrySet()) {
                            newMeta.addEnchant(e.getKey(), e.getValue(), true);
                        }
                        nItem.setItemMeta(newMeta);
                    }
                    return nItem;
                }
            }
        }
        return it;
    }

    public boolean hasKitPermission(Player p, String n) {
        if (n.contains("yetkili")) return p.hasPermission("kit.yetkili");
        if (p.hasPermission("kit.admin")) return true;
        if (n.contains("admin")) return false;
        if (n.contains("medya")) return p.hasPermission("kit.medya");
        if (n.contains("bilgili")) return p.hasPermission("kit.bilgili");
        return true;
    }

    public String getDenyMessage(String n) {
        if (n.contains("admin")) return "&8[&6Kit&8] &cBu kit sadece adminler içindir!";
        if (n.contains("yetkili")) return "&8[&6Kit&8] &cYetkili kitini açmak için Rehber ve üzeri yetkin olmalı!";
        if (n.contains("medya")) return "&8[&6Kit&8] &cBu kit sadece medyalar içindir!";
        if (n.contains("bilgili")) return "&8[&6Kit&8] &cBu kit sadece bilgililer içindir!";
        return "&8[&6Kit&8] &cBu kiti alma yetkin yok!";
    }

    public String formatTime(long sec) {
        long g = sec / 86400; sec %= 86400;
        long sa = sec / 3600; sec %= 3600;
        long d = sec / 60; long s = sec % 60;
        List<String> parts = new ArrayList<>();
        if (g > 0) parts.add(g + " gün");
        if (sa > 0) parts.add(sa + " saat");
        if (d > 0) parts.add(d + " dakika");
        if (s > 0) parts.add(s + " saniye");
        return parts.isEmpty() ? "0 saniye" : String.join(" ", parts);
    }

    public void openMenu(Player p) {
        Inventory gui = Bukkit.createInventory(null, 27, Component.text("Kits"));
        ItemStack pane1 = createGlass(Material.PURPLE_STAINED_GLASS_PANE);
        ItemStack pane2 = createGlass(Material.MAGENTA_STAINED_GLASS_PANE);
        for (int i = 0; i < 27; i++) gui.setItem(i, (i % 2 == 0) ? pane1 : pane2);

        Map<Integer, String> slotMap = new HashMap<>();
        Set<Integer> usedSlots = new HashSet<>();
        int[] fallbackSlots = {10, 12, 14, 16, 11, 13, 15};

        List<String> kits = getKitList();
        for (String k : kits) {
            int fixed = getFixedSlot(k);
            if (fixed != -1) {
                slotMap.put(fixed, k);
                usedSlots.add(fixed);
            }
        }
        for (String k : kits) {
            if (!slotMap.containsValue(k)) {
                for (int s : fallbackSlots) {
                    if (!usedSlots.contains(s)) {
                        slotMap.put(s, k);
                        usedSlots.add(s);
                        break;
                    }
                }
            }
        }

        for (Map.Entry<Integer, String> entry : slotMap.entrySet()) {
            int slot = entry.getKey();
            String kn = entry.getValue();
            Material icon = getIconMaterial(kn);
            ItemStack item = new ItemStack(icon);
            ItemMeta meta = item.getItemMeta();
            String display = kn.contains("yetkili") ? "Yetkili" : kn;
            int itemCount = 0;
            ConfigurationSection sec = data.getConfigurationSection("kits." + kn + ".items");
            if (sec != null) itemCount = sec.getKeys(false).size();
            long cd = data.getLong("kits." + kn + ".cd", 0);

            boolean allowed = hasKitPermission(p, kn);
            meta.displayName(LEGACY.deserialize((allowed ? "&e&l" : "&c&l") + display));
            List<Component> lore = Arrays.asList(
                    LEGACY.deserialize("&7İçerik: &f" + itemCount + " eşya"),
                    LEGACY.deserialize("&7Bekleme: &f" + formatTime(cd)),
                    Component.empty(),
                    LEGACY.deserialize(allowed ? "&aAlmak için tıkla!" : "&c&lKilitli")
            );
            meta.lore(lore);
            item.setItemMeta(meta);
            gui.setItem(slot, item);
        }

        openMenus.put(p.getUniqueId(), slotMap);
        p.openInventory(gui);
    }

    public void giveKit(Player p, String n) {
        if (!kitExists(n)) {
            p.sendMessage(LEGACY.deserialize("&8[&6Kit&8] &cBu kit artık yok!"));
            return;
        }
        if (!hasKitPermission(p, n)) {
            p.sendMessage(LEGACY.deserialize(getDenyMessage(n)));
            return;
        }
        long cd = data.getLong("kits." + n + ".cd", 0);
        if (cd > 0 && !p.hasPermission("kit.bypass")) {
            long last = data.getLong("cooldowns." + p.getUniqueId() + "." + n, 0);
            long diff = (System.currentTimeMillis() - last) / 1000;
            if (diff < cd) {
                p.sendMessage(LEGACY.deserialize("&8[&6Kit&8] &cBu kiti tekrar almak için &e" + formatTime(cd - diff) + " &cbeklemelisin!"));
                return;
            }
        }
        data.set("cooldowns." + p.getUniqueId() + "." + n, System.currentTimeMillis());
        saveKits();

        ConfigurationSection sec = data.getConfigurationSection("kits." + n + ".items");
        if (sec != null) {
            for (String key : sec.getKeys(false)) {
                int slot = Integer.parseInt(key);
                ItemStack it = sec.getItemStack(key);
                if (it == null) continue;
                ItemStack cur = p.getInventory().getItem(slot);
                if (cur == null || cur.getType() == Material.AIR) {
                    p.getInventory().setItem(slot, it.clone());
                } else {
                    p.getInventory().addItem(it.clone()).values().forEach(rem -> p.getWorld().dropItemNaturally(p.getLocation(), rem));
                }
            }
        }
        p.sendMessage(LEGACY.deserialize("&8[&6Kit&8] &e" + n + " &akitini aldın!"));
        p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
    }

    private int getFixedSlot(String n) {
        if (n.contains("admin")) return 16;
        if (n.contains("yetkili")) return 14;
        if (n.contains("medya")) return 12;
        if (n.contains("bilgili")) return 15;
        if (n.contains("başlangıç") || n.contains("baslangic")) return 10;
        return -1;
    }

    private Material getIconMaterial(String n) {
        if (n.contains("admin")) return Material.RED_SHULKER_BOX;
        if (n.contains("yetkili")) return Material.CYAN_SHULKER_BOX;
        if (n.contains("medya")) return Material.BLUE_SHULKER_BOX;
        if (n.contains("bilgili")) return Material.LIME_SHULKER_BOX;
        if (n.contains("başlangıç") || n.contains("baslangic")) return Material.ORANGE_SHULKER_BOX;
        return Material.PURPLE_SHULKER_BOX;
    }

    private ItemStack createGlass(Material mat) {
        ItemStack it = new ItemStack(mat);
        ItemMeta m = it.getItemMeta();
        m.displayName(Component.text(" "));
        it.setItemMeta(m);
        return it;
    }
}
