package com.kratossmp.plugin.managers;

import com.kratossmp.plugin.KratosPlugin;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.Container;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class KratosToolManager {
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();
    private final KratosPlugin plugin;
    private final NamespacedKey idKey;
    private final File file;
    private YamlConfiguration data;

    public final Set<UUID> openAdminMenu = new HashSet<>();
    public final Map<UUID, Location> openSellMenu = new HashMap<>();

    public KratosToolManager(KratosPlugin plugin) {
        this.plugin = plugin;
        this.idKey = new NamespacedKey(plugin, "kratos_tool_id");
        this.file = new File(plugin.getDataFolder(), "kratostools.yml");
        if (!file.exists()) {
            try { file.createNewFile(); } catch (IOException ignored) {}
        }
        this.data = YamlConfiguration.loadConfiguration(file);
    }

    public void saveData() {
        try { data.save(file); } catch (IOException ignored) {}
    }

    public ItemStack createTool(String type) {
        int nextId = data.getInt("counter", 0) + 1;
        data.set("counter", nextId);
        String id = String.valueOf(nextId);

        ItemStack item;
        String name;
        String d1;
        String d2;

        switch (type.toLowerCase(Locale.ROOT)) {
            case "kazma" -> {
                item = new ItemStack(Material.NETHERITE_PICKAXE);
                item.addUnsafeEnchantment(Enchantment.EFFICIENCY, 5);
                item.addUnsafeEnchantment(Enchantment.UNBREAKING, 3);
                item.addUnsafeEnchantment(Enchantment.FORTUNE, 3);
                name = "&4&lKratos Kazma";
                d1 = "&7Tek seferde &c3x3x2 &7(18 blok) kazar.";
                d2 = "&7Kratos'a özel alet.";
            }
            case "ipekkazma" -> {
                item = new ItemStack(Material.NETHERITE_PICKAXE);
                item.addUnsafeEnchantment(Enchantment.EFFICIENCY, 5);
                item.addUnsafeEnchantment(Enchantment.UNBREAKING, 3);
                item.addUnsafeEnchantment(Enchantment.SILK_TOUCH, 1);
                name = "&4&lİpeksi Kratos Kazma";
                d1 = "&7Tek seferde &c3x3x2 &7(18 blok) kazar.";
                d2 = "&7İpeksi dokunuşlu Kratos aleti.";
            }
            case "balta" -> {
                item = new ItemStack(Material.NETHERITE_AXE);
                item.addUnsafeEnchantment(Enchantment.EFFICIENCY, 5);
                item.addUnsafeEnchantment(Enchantment.UNBREAKING, 3);
                name = "&4&lKratos Balta";
                d1 = "&7Tek seferde &cağacın tamamını &7keser.";
                d2 = "&7Kratos'a özel alet.";
            }
            case "kurek" -> {
                item = new ItemStack(Material.NETHERITE_SHOVEL);
                item.addUnsafeEnchantment(Enchantment.EFFICIENCY, 5);
                item.addUnsafeEnchantment(Enchantment.UNBREAKING, 3);
                name = "&4&lKratos Kürek";
                d1 = "&7Tek seferde &c3x3x2 &7(18 blok) toprak kazar.";
                d2 = "&7Kratos'a özel alet.";
            }
            default -> {
                item = new ItemStack(Material.STICK);
                item.addUnsafeEnchantment(Enchantment.UNBREAKING, 10);
                name = "&4&lKratos Satış Çubuğu";
                d1 = "&7Sandık, fıçı veya shulker'a &csağ tıkla&7.";
                d2 = "&7Order veya /sell seç, hepsi satılsın.";
                ItemMeta meta = item.getItemMeta();
                meta.displayName(LEGACY.deserialize(name));
                meta.lore(Arrays.asList(LEGACY.deserialize(d1), LEGACY.deserialize(d2), LEGACY.deserialize("&8ID: " + id)));
                meta.getPersistentDataContainer().set(idKey, PersistentDataType.STRING, id);
                item.setItemMeta(meta);
                saveData();
                return item;
            }
        }

        data.set("tools." + id + ".left", 4320.0);
        data.set("tools." + id + ".active", false);
        saveData();

        ItemMeta meta = item.getItemMeta();
        meta.displayName(LEGACY.deserialize(name));
        meta.lore(Arrays.asList(
                LEGACY.deserialize(getLeftText(id)),
                LEGACY.deserialize(d1),
                LEGACY.deserialize(d2),
                LEGACY.deserialize("&8ID: " + id)
        ));
        meta.getPersistentDataContainer().set(idKey, PersistentDataType.STRING, id);
        item.setItemMeta(meta);
        return item;
    }

    public String getToolId(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return "";
        String id = it.getItemMeta().getPersistentDataContainer().get(idKey, PersistentDataType.STRING);
        return id != null ? id : "";
    }

    public String getToolType(ItemStack it) {
        if (it == null || !it.hasItemMeta() || !it.getItemMeta().hasDisplayName()) return "none";
        String plain = PlainTextComponentSerializer.plainText().serialize(it.getItemMeta().displayName());
        if (it.getType() == Material.NETHERITE_PICKAXE && (plain.equals("Kratos Kazma") || plain.equals("İpeksi Kratos Kazma"))) return "pickaxe";
        if (it.getType() == Material.NETHERITE_AXE && plain.equals("Kratos Balta")) return "axe";
        if (it.getType() == Material.NETHERITE_SHOVEL && plain.equals("Kratos Kürek")) return "shovel";
        return "none";
    }

    public boolean isSatisCubugu(ItemStack it) {
        if (it == null || it.getType() != Material.STICK || !it.hasItemMeta() || !it.getItemMeta().hasDisplayName()) return false;
        return PlainTextComponentSerializer.plainText().serialize(it.getItemMeta().displayName()).equals("Kratos Satış Çubuğu");
    }

    public boolean isExpired(String id) {
        if (id.isEmpty()) return false;
        return data.getDouble("tools." + id + ".left", 0.0) <= 0.0;
    }

    public void activateTool(String id) {
        if (!id.isEmpty() && !data.getBoolean("tools." + id + ".active", false)) {
            data.set("tools." + id + ".active", true);
        }
    }

    public String getLeftText(String id) {
        double m = data.getDouble("tools." + id + ".left", 0.0);
        if (m <= 0) return "&cSüresi doldu";
        if (!data.getBoolean("tools." + id + ".active", false) && m >= 4320.0) {
            return "&7Süre: &eİlk kullanımda başlar";
        }
        long t = Math.round(m * 60) - 1;
        if (t <= 0) return "&cSüresi doldu";
        long d = t / 86400; t %= 86400;
        long hh = t / 3600; t %= 3600;
        long mm = t / 60;
        return "&7Kalan süre: &e" + d + " gün " + hh + " saat " + mm + " dakika";
    }

    public void tickHeldTools() {
        double dec = 1.0 / 60.0;
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.getGameMode() == GameMode.CREATIVE) continue;
            ItemStack it = p.getInventory().getItemInMainHand();
            if (getToolType(it).equals("none")) continue;
            String id = getToolId(it);
            if (id.isEmpty()) continue;
            if (!data.getBoolean("tools." + id + ".active", false) && data.getDouble("tools." + id + ".left", 4320.0) >= 4320.0) continue;

            double left = data.getDouble("tools." + id + ".left", 0.0) - dec;
            if (left < 0.001) left = 0.0;
            data.set("tools." + id + ".left", left);

            if (left <= 0.0) {
                p.getInventory().setItemInMainHand(new ItemStack(Material.AIR));
                p.sendMessage(LEGACY.deserialize("&cKratos aletinin 3 günlük süresi doldu ve yok oldu!"));
                continue;
            }
            ItemMeta meta = it.getItemMeta();
            List<Component> lore = meta.lore();
            if (lore != null && !lore.isEmpty()) {
                Component updated = LEGACY.deserialize(getLeftText(id));
                if (!lore.get(0).equals(updated)) {
                    lore.set(0, updated);
                    meta.lore(lore);
                    it.setItemMeta(meta);
                }
            }
        }
    }

    public void openAdminMenu(Player p) {
        Inventory inv = Bukkit.createInventory(null, 27, LEGACY.deserialize("&c&lKratos Aletler"));
        ItemStack red = new ItemStack(Material.RED_STAINED_GLASS_PANE);
        ItemMeta rm = red.getItemMeta(); rm.displayName(Component.text(" ")); red.setItemMeta(rm);
        for (int i = 0; i < 27; i++) inv.setItem(i, red);

        inv.setItem(11, previewItem(Material.NETHERITE_PICKAXE, "&4&lKratos Kazma", "&7Tek seferde &c3x3x2 &7(18 blok) kazar."));
        inv.setItem(12, previewItem(Material.NETHERITE_AXE, "&4&lKratos Balta", "&7Tek seferde &cağacın tamamını &7keser."));
        inv.setItem(13, previewItem(Material.NETHERITE_SHOVEL, "&4&lKratos Kürek", "&7Tek seferde &c3x3x2 &7(18 blok) toprak kazar."));
        inv.setItem(14, previewItem(Material.NETHERITE_PICKAXE, "&4&lİpeksi Kratos Kazma", "&7Tek seferde &c3x3x2 &7(18 blok) kazar."));
        inv.setItem(15, previewItem(Material.STICK, "&4&lKratos Satış Çubuğu", "&7Sandık, fıçı veya shulker'a &csağ tıkla&7."));

        openAdminMenu.add(p.getUniqueId());
        p.openInventory(inv);
    }

    private ItemStack previewItem(Material m, String name, String desc) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(LEGACY.deserialize(name));
        meta.lore(Arrays.asList(LEGACY.deserialize(desc), Component.empty(), LEGACY.deserialize("&eAlmak için tıkla!")));
        it.setItemMeta(meta);
        return it;
    }

    public void giveItem(Player p, ItemStack it) {
        p.getInventory().addItem(it).values().forEach(rem -> p.getWorld().dropItemNaturally(p.getLocation(), rem));
        p.playSound(p.getLocation(), Sound.ENTITY_ITEM_PICKUP, 1.0f, 1.0f);
    }

    public void openSellStickMenu(Player p, Block b) {
        if (!(b.getState() instanceof Container c)) return;
        double totalSell = 0;
        for (ItemStack it : c.getInventory().getContents()) {
            if (it != null && it.getType() != Material.AIR) {
                double pr = plugin.getSellManager().getPrice(it);
                if (pr > 0) totalSell += pr * it.getAmount();
            }
        }
        Inventory inv = Bukkit.createInventory(null, 27, Component.text("Kratos Satış"));
        ItemStack pane = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta pm = pane.getItemMeta(); pm.displayName(Component.text(" ")); pane.setItemMeta(pm);
        for (int i = 0; i < 27; i++) inv.setItem(i, pane);

        ItemStack sellBtn = new ItemStack(Material.EMERALD);
        ItemMeta sm = sellBtn.getItemMeta();
        sm.displayName(LEGACY.deserialize("&a&l/sell'e Sat"));
        sm.lore(Arrays.asList(
                LEGACY.deserialize("&7/sell fiyatından satılır."),
                Component.empty(),
                LEGACY.deserialize("&7Toplam: &a" + (Math.round(totalSell * 100.0) / 100.0)),
                Component.empty(),
                LEGACY.deserialize("&eSatmak için tıkla!")
        ));
        sellBtn.setItemMeta(sm);
        inv.setItem(15, sellBtn);

        openSellMenu.put(p.getUniqueId(), b.getLocation());
        p.openInventory(inv);
    }

    public void executeSellStick(Player p, Location loc) {
        Block b = loc.getBlock();
        if (!(b.getState() instanceof Container c)) {
            p.sendMessage(LEGACY.deserialize("&cKonteyner artık yok!"));
            return;
        }
        double total = 0;
        int count = 0;
        Inventory inv = c.getInventory();
        for (int i = 0; i < inv.getSize(); i++) {
            ItemStack it = inv.getItem(i);
            if (it == null || it.getType() == Material.AIR) continue;
            if (it.getType().name().contains("SHULKER_BOX")) continue;
            double pr = plugin.getSellManager().getPrice(it);
            if (pr > 0) {
                total += pr * it.getAmount();
                count += it.getAmount();
                inv.setItem(i, null);
            }
        }
        if (count == 0) {
            p.sendMessage(LEGACY.deserialize("&cSatılabilir eşya bulunamadı!"));
            return;
        }
        total = Math.round(total * 100.0) / 100.0;
        if (plugin.getEconomy() != null) plugin.getEconomy().depositPlayer(p, total);
        p.sendMessage(LEGACY.deserialize("&a/sell'e &e" + count + " &aeşya satıldı: &a+" + total));
        p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.0f);
    }
}
