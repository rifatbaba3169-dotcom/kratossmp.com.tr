package com.kratossmp.plugin.tasks;

import com.kratossmp.plugin.KratosPlugin;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class OnlineRewardTask extends BukkitRunnable {
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();
    private final KratosPlugin plugin;
    private final Map<UUID, Integer> playTime = new HashMap<>();

    public OnlineRewardTask(KratosPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public void run() {
        int odulSuresi = plugin.getConfig().getInt("rewards.odul-suresi", 900);
        int kasaAdedi = plugin.getConfig().getInt("rewards.kasa-adedi", 2);

        for (Player p : Bukkit.getOnlinePlayers()) {
            int sure = playTime.getOrDefault(p.getUniqueId(), 0) + 1;
            if (sure >= odulSuresi) {
                playTime.put(p.getUniqueId(), 0);
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "crate giveKey oyuncu " + p.getName() + " " + kasaAdedi);
                p.sendMessage(LEGACY.deserialize("&a[Sunucu] &f15 dakika online süren doldu, &e" + kasaAdedi + " adet kasa anahtarı kazandın!"));
            } else {
                playTime.put(p.getUniqueId(), sure);
            }
        }
    }

    public int getRemainingSeconds(UUID uuid) {
        int odulSuresi = plugin.getConfig().getInt("rewards.odul-suresi", 900);
        int current = playTime.getOrDefault(uuid, 0);
        return Math.max(0, odulSuresi - current);
    }
}
