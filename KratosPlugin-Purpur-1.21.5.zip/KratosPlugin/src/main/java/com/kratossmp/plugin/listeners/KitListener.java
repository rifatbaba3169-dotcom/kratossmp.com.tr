package com.kratossmp.plugin.listeners;

import com.kratossmp.plugin.managers.KitManager;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.Map;

public class KitListener implements Listener {
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();
    private final KitManager manager;

    public KitListener(KitManager manager) {
        this.manager = manager;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        Map<Integer, String> map = manager.openMenus.get(p.getUniqueId());
        if (map == null) return;
        e.setCancelled(true);
        if (e.getClickedInventory() == null || e.getClickedInventory().equals(p.getInventory())) return;
        String kitName = map.get(e.getSlot());
        if (kitName != null) {
            if (!manager.hasKitPermission(p, kitName)) {
                p.sendMessage(LEGACY.deserialize(manager.getDenyMessage(kitName)));
                p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 1.0f, 1.0f);
                return;
            }
            manager.giveKit(p, kitName);
            p.closeInventory();
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (manager.openMenus.containsKey(e.getWhoClicked().getUniqueId())) e.setCancelled(true);
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        manager.openMenus.remove(e.getPlayer().getUniqueId());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        manager.openMenus.remove(e.getPlayer().getUniqueId());
    }
}
