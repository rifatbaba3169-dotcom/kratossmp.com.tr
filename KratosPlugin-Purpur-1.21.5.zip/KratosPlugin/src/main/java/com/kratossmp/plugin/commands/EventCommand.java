package com.kratossmp.plugin.commands;

import com.kratossmp.plugin.KratosPlugin;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.jetbrains.annotations.NotNull;

public class EventCommand implements CommandExecutor {
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (!sender.hasPermission("event.modu")) {
            sender.sendMessage(LEGACY.deserialize("&cYetkin yok!"));
            return true;
        }
        if (args.length > 0 && args[0].equalsIgnoreCase("modu")) {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "duyuru EVENT BASLIYOR");
            Bukkit.getScheduler().runTaskLater(KratosPlugin.getInstance(), () ->
                    Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "crate giveKeyAll Ametist 3"), 100L);
            Bukkit.getScheduler().runTaskLater(KratosPlugin.getInstance(), () ->
                    Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "crate giveKeyAll Exe 3"), 200L);
            Bukkit.getScheduler().runTaskLater(KratosPlugin.getInstance(), () -> {
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "crate giveKeyAll Set 3");
                sender.sendMessage(LEGACY.deserialize("&aEvent başarıyla başlatıldı!"));
            }, 300L);
        }
        return true;
    }
}
