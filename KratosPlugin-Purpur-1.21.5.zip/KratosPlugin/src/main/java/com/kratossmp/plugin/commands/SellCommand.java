package com.kratossmp.plugin.commands;

import com.kratossmp.plugin.managers.SellManager;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class SellCommand implements CommandExecutor {
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();
    private final SellManager manager;

    public SellCommand(SellManager manager) {
        this.manager = manager;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        String cmd = command.getName().toLowerCase();
        if (cmd.equals("sellfiyat")) {
            if (sender instanceof Player p && !p.isOp()) {
                p.sendMessage(LEGACY.deserialize("&cBu komutu sadece OP'ler kullanabilir."));
                return true;
            }
            if (args.length > 0 && args[0].equalsIgnoreCase("yenile")) {
                manager.loadPrices();
                sender.sendMessage(LEGACY.deserialize("&aFiyat tablosu yenilendi: &e" + manager.getSellableCount() + " &aeşya satılabilir."));
            } else {
                sender.sendMessage(LEGACY.deserialize("&e/sellfiyat yenile &7- fiyat tablosunu yeniler"));
            }
            return true;
        }

        if (!(sender instanceof Player p)) {
            sender.sendMessage(LEGACY.deserialize("&cBu komutu sadece oyuncular kullanabilir."));
            return true;
        }
        manager.openSellMenu(p);
        return true;
    }
}
