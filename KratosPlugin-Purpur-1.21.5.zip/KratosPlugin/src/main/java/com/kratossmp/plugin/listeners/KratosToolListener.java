package com.kratossmp.plugin.listeners;

import com.kratossmp.plugin.managers.KratosToolManager;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

import java.util.*;

public class KratosToolListener implements Listener {
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();
    private final KratosToolManager manager;
    private final Set<UUID> breakingLock = new HashSet<>();

    public KratosToolListener(KratosToolManager manager) {
        this.manager = manager;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        if (breakingLock.contains(p.getUniqueId())) return;
        if (p.getGameMode() == GameMode.CREATIVE) return;
        Block b = e.getBlock();
        if (b.getType() == Material.SPAWNER) return;

        ItemStack tool = p.getInventory().getItemInMainHand();
        String type = manager.getToolType(tool);
        if (type.equals("none")) return;

        String id = manager.getToolId(tool);
        if (manager.isExpired(id)) {
            e.setCancelled(true);
            p.getInventory().setItemInMainHand(new ItemStack(Material.AIR));
            p.sendMessage(LEGACY.deserialize("&cKratos aletinin 3 günlük süresi doldu ve yok oldu!"));
            return;
        }

        manager.activateTool(id);

        breakingLock.add(p.getUniqueId());
        try {
            if (type.equals("axe")) {
                if (isLog(b.getType())) breakTree(p, b, tool);
            } else if (type.equals("pickaxe") || type.equals("shovel")) {
                breakArea(p, b, tool, type);
            }
        } finally {
            breakingLock.remove(p.getUniqueId());
        }
    }

    private boolean isLog(Material m) {
        String n = m.name();
        return n.endsWith("_LOG") || n.endsWith("_WOOD") || n.endsWith("_STEM") || n.endsWith("_HYPHAE");
    }

    private boolean isAllowed(Material m, String kind) {
        if (m.isAir() || m == Material.WATER || m == Material.LAVA) return false;
        String n = m.name();
        if (n.contains("BEDROCK") || n.contains("BARRIER") || n.contains("SPAWNER") || n.contains("REINFORCED_DEEPSLATE")
                || n.contains("END_PORTAL") || n.contains("COMMAND_BLOCK") || n.contains("CHEST") || n.contains("BARREL")
                || n.contains("HOPPER") || n.contains("DROPPER") || n.contains("DISPENSER") || n.contains("FURNACE") || n.contains("SMOKER")) {
            return false;
        }
        if (kind.equals("shovel")) {
            if (n.contains("SANDSTONE")) return false;
            return n.contains("DIRT") || n.contains("GRASS_BLOCK") || n.contains("SAND") || n.contains("GRAVEL")
                    || n.contains("CLAY") || n.contains("SNOW") || n.contains("MUD") || n.contains("PODZOL")
                    || n.contains("MYCELIUM") || n.contains("FARMLAND") || n.contains("CONCRETE_POWDER");
        }
        return true;
    }

    private void breakTree(Player p, Block start, ItemStack tool) {
        Queue<Block> queue = new ArrayDeque<>();
        Set<Location> visited = new HashSet<>();
        queue.add(start);
        visited.add(start.getLocation());
        int count = 0;

        while (!queue.isEmpty() && count < 200) {
            Block cur = queue.poll();
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        Block nb = cur.getRelative(dx, dy, dz);
                        if (visited.add(nb.getLocation()) && isLog(nb.getType())) {
                            queue.add(nb);
                            nb.breakNaturally(tool);
                            count++;
                        }
                    }
                }
            }
        }
    }

    private void breakArea(Player p, Block center, ItemStack tool, String kind) {
        float pitch = p.getLocation().getPitch();
        float yaw = p.getLocation().getYaw();
        if (yaw < 0) yaw += 360;

        String mode = "x";
        if (yaw >= 315 || yaw < 45 || (yaw >= 135 && yaw < 225)) mode = "z";
        if (Math.abs(pitch) > 50) mode = "y";

        int ddx = 0, ddy = 0, ddz = 0;
        if (mode.equals("y")) ddy = pitch > 0 ? -1 : 1;
        else if (mode.equals("z")) ddz = (yaw < 90 || yaw >= 270) ? 1 : -1;
        else ddx = yaw < 180 ? -1 : 1;

        for (int d = 0; d <= 1; d++) {
            for (int a = -1; a <= 1; a++) {
                for (int c = -1; c <= 1; c++) {
                    if (d == 0 && a == 0 && c == 0) continue;
                    int dx = ddx * d, dy = ddy * d, dz = ddz * d;
                    if (mode.equals("y")) { dx += a; dz += c; }
                    else if (mode.equals("z")) { dx += a; dy += c; }
                    else { dy += a; dz += c; }

                    Block target = center.getRelative(dx, dy, dz);
                    if (isAllowed(target.getType(), kind)) {
                        target.breakNaturally(tool);
                    }
                }
            }
        }
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK || e.getClickedBlock() == null) return;
        Player p = e.getPlayer();
        if (!manager.isSatisCubugu(p.getInventory().getItemInMainHand())) return;
        Material m = e.getClickedBlock().getType();
        if (m == Material.CHEST || m == Material.TRAPPED_CHEST || m == Material.BARREL || m.name().contains("SHULKER_BOX")) {
            e.setCancelled(true);
            if (!manager.openSellMenu.containsKey(p.getUniqueId())) {
                manager.openSellStickMenu(p, e.getClickedBlock());
            }
        }
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        InventoryType type = e.getInventory().getType();
        if ((type == InventoryType.ANVIL || type == InventoryType.GRINDSTONE) && e.getSlot() == 2) {
            ItemStack a = e.getInventory().getItem(0);
            ItemStack b = e.getInventory().getItem(1);
            if (!manager.getToolType(a).equals("none") || !manager.getToolType(b).equals("none")) {
                e.setCancelled(true);
                p.sendMessage(LEGACY.deserialize("&cKratos aletleri onarılamaz veya değiştirilemez!"));
                return;
            }
        }

        if (manager.openAdminMenu.contains(p.getUniqueId())) {
            e.setCancelled(true);
            if (e.getClickedInventory() == null || e.getClickedInventory().equals(p.getInventory())) return;
            if (!p.isOp()) { p.closeInventory(); return; }
            switch (e.getSlot()) {
                case 11 -> { manager.giveItem(p, manager.createTool("kazma")); p.sendMessage(LEGACY.deserialize("&cKratos Kazma &7verildi.")); }
                case 12 -> { manager.giveItem(p, manager.createTool("balta")); p.sendMessage(LEGACY.deserialize("&cKratos Balta &7verildi.")); }
                case 13 -> { manager.giveItem(p, manager.createTool("kurek")); p.sendMessage(LEGACY.deserialize("&cKratos Kürek &7verildi.")); }
                case 14 -> { manager.giveItem(p, manager.createTool("ipekkazma")); p.sendMessage(LEGACY.deserialize("&cİpeksi Kratos Kazma &7verildi.")); }
                case 15 -> { manager.giveItem(p, manager.createTool("cubuk")); p.sendMessage(LEGACY.deserialize("&cKratos Satış Çubuğu &7verildi.")); }
            }
            return;
        }

        if (manager.openSellMenu.containsKey(p.getUniqueId())) {
            e.setCancelled(true);
            if (e.getClickedInventory() == null || e.getClickedInventory().equals(p.getInventory())) return;
            if (e.getSlot() == 15) {
                Location loc = manager.openSellMenu.remove(p.getUniqueId());
                p.closeInventory();
                if (loc != null) manager.executeSellStick(p, loc);
            }
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        UUID id = e.getWhoClicked().getUniqueId();
        if (manager.openAdminMenu.contains(id) || manager.openSellMenu.containsKey(id)) e.setCancelled(true);
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        manager.openAdminMenu.remove(id);
        manager.openSellMenu.remove(id);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        manager.openAdminMenu.remove(id);
        manager.openSellMenu.remove(id);
    }
}
