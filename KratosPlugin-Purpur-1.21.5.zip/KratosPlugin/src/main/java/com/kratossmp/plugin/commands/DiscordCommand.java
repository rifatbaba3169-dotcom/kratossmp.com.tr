package com.kratossmp.plugin.commands;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class DiscordCommand implements CommandExecutor {
    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Bu komut sadece oyuncular içindir.");
            return true;
        }
        Component message = MiniMessage.miniMessage().deserialize("<#00ffff><b>KratosSMP</b></#00ffff> <dark_gray>»</dark_gray> <white>Discord sunucumuza katılmak için</white> <click:open_url:'https://discord.gg/nbXKb46fvZ'><underlined><#00ffff>tıkla!</underlined></click>");
        player.sendMessage(message);
        return true;
    }
}
