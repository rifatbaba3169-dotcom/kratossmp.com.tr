package com.kratossmp.plugin.commands;

import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.time.Duration;

public class DuyuruCommand implements CommandExecutor {
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (!sender.hasPermission("exesmp.duyuru")) {
            sender.sendMessage(LEGACY.deserialize("&cYetkin yok!"));
            return true;
        }
        if (args.length == 0) {
            sender.sendMessage(LEGACY.deserialize("&c&lHATA » &fLütfen bir duyuru metni gir! &eKullanım: /duyuru <mesaj> &fveya &e/duyuru Başlık | Alt Başlık"));
            return true;
        }
        String fullArg = String.join(" ", args);
        Title.Times times = Title.Times.times(Duration.ofSeconds(1), Duration.ofSeconds(5), Duration.ofSeconds(1));

        if (fullArg.contains("|")) {
            String[] parts = fullArg.split("\\|", 2);
            String p1 = parts[0].trim();
            String p2 = parts[1].trim();
            Title title = Title.title(LEGACY.deserialize("&b&l&nDUYURU"), LEGACY.deserialize("&e" + p2), times);
            for (Player p : Bukkit.getOnlinePlayers()) {
                p.showTitle(title);
                p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
            }
            Bukkit.broadcast(LEGACY.deserialize(""));
            Bukkit.broadcast(LEGACY.deserialize("&b&lKratosSMP &8» &d&lDUYURU &8«"));
            Bukkit.broadcast(LEGACY.deserialize("&f" + p1));
            Bukkit.broadcast(LEGACY.deserialize("&e" + p2));
            Bukkit.broadcast(LEGACY.deserialize(""));
        } else {
            Title title = Title.title(LEGACY.deserialize("&b&l&nDUYURU"), LEGACY.deserialize("&a" + fullArg), times);
            for (Player p : Bukkit.getOnlinePlayers()) {
                p.showTitle(title);
                p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
            }
            Bukkit.broadcast(LEGACY.deserialize(""));
            Bukkit.broadcast(LEGACY.deserialize("&b&lKratosSMP &8» &d&lDUYURU &8«"));
            Bukkit.broadcast(LEGACY.deserialize("&f" + fullArg));
            Bukkit.broadcast(LEGACY.deserialize(""));
        }
        return true;
    }
}
