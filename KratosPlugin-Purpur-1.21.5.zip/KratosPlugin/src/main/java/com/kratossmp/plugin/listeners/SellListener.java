package com.kratossmp.plugin.listeners;

import com.kratossmp.plugin.KratosPlugin;
import com.kratossmp.plugin.managers.SellManager;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

public class SellListener implements Listener {
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();
    private final SellManager manager;

    public SellListener(SellManager manager) {
        this.manager = manager;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        UUID u = p.getUniqueId();

        if (manager.openMain.contains(u)) {
            if (e.getClickedInventory() == null || e.getClickedInventory().equals(p.getInventory())) return;
            int idx = e.getSlot();
            if (idx >= 45) {
                e.setCancelled(true);
                if (idx == 45) {
                    manager.openMain.remove(u);
                    Bukkit.getScheduler().runTaskLater(KratosPlugin.getInstance(), () -> manager.openMultiplierMenu(p), 1L);
                } else if (idx == 48) {
                    Inventory inv = e.getInventory();
                    double total = 0;
                    int count = 0;
                    Map<String, Double> multInfo = new LinkedHashMap<>();
                    for (int i = 0; i < 45; i++) {
                        ItemStack it = inv.getItem(i);
                        if (it != null && it.getType() != Material.AIR) {
                            double pr = manager.getPrice(it);
                            if (pr > 0) {
                                int amt = it.getAmount();
                                String ck = manager.getMultiplierKey(it.getType());
                                if (ck.isEmpty()) {
                                    total += pr * amt;
                                } else {
                                    total += manager.sellWithMultiplier(u, ck, pr, amt);
                                    multInfo.put(ck, manager.getMultiplier(u, ck));
                                }
                                count += amt;
                            } else {
                                giveBack(p, it);
                            }
                            inv.setItem(i, null);
                        }
                    }
                    if (count > 0) {
                        total = Math.round(total * 100.0) / 100.0;
                        if (KratosPlugin.getInstance().getEconomy() != null) {
                            KratosPlugin.getInstance().getEconomy().depositPlayer(p, total);
                        }
                        p.sendMessage(LEGACY.deserialize("&aToplam &e" + count + " &aeşya satıldı ve &e" + total + " &aparan hesabına yatırıldı!"));
                        p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
                        for (Map.Entry<String, Double> entry : multInfo.entrySet()) {
                            p.sendMessage(LEGACY.deserialize("&7" + entry.getKey() + " çarpanın: &e" + entry.getValue() + "x"));
                        }
                    } else {
                        p.sendMessage(LEGACY.deserialize("&cSatılabilir eşya yok. Fiyatı olmayan eşyalar geri verildi."));
                    }
                    p.closeInventory();
                } else if (idx == 50) {
                    p.sendMessage(LEGACY.deserialize("&cSatış iptal edildi, eşyaların geri verildi."));
                    p.closeInventory();
                } else if (idx == 53) {
                    manager.openMain.remove(u);
                    manager.searchQuery.remove(u);
                    manager.searchResults.remove(u);
                    Bukkit.getScheduler().runTaskLater(KratosPlugin.getInstance(), () -> manager.openListMenu(p, 1), 1L);
                }
            }
            return;
        }

        if (manager.openMultipliers.contains(u)) {
            e.setCancelled(true);
            if (e.getSlot() == 49 && e.getCurrentItem() != null && e.getCurrentItem().getType() == Material.BARRIER) {
                manager.openMultipliers.remove(u);
                Bukkit.getScheduler().runTaskLater(KratosPlugin.getInstance(), () -> manager.openSellMenu(p), 1L);
            }
            return;
        }

        if (manager.openListPage.containsKey(u)) {
            e.setCancelled(true);
            int pg = manager.openListPage.get(u);
            switch (e.getSlot()) {
                case 45 -> { if (pg > 1) Bukkit.getScheduler().runTaskLater(KratosPlugin.getInstance(), () -> manager.openListMenu(p, pg - 1), 1L); }
                case 53 -> Bukkit.getScheduler().runTaskLater(KratosPlugin.getInstance(), () -> manager.openListMenu(p, pg + 1), 1L);
                case 48 -> {
                    manager.openListPage.remove(u);
                    manager.searchQuery.remove(u);
                    manager.searchResults.remove(u);
                    Bukkit.getScheduler().runTaskLater(KratosPlugin.getInstance(), () -> manager.openSellMenu(p), 1L);
                }
                case 46 -> {
                    manager.searchQuery.remove(u);
                    manager.searchResults.remove(u);
                    Bukkit.getScheduler().runTaskLater(KratosPlugin.getInstance(), () -> manager.openListMenu(p, 1), 1L);
                }
                case 50 -> {
                    manager.openListPage.remove(u);
                    p.closeInventory();
                    manager.waitingSearch.add(u);
                    p.sendMessage(LEGACY.deserialize("&bAramak istediğin eşyanın adını sohbete yaz &7(iptal için &fiptal&7)."));
                    Bukkit.getScheduler().runTaskLater(KratosPlugin.getInstance(), () -> manager.waitingSearch.remove(u), 600L);
                }
            }
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        Player p = (Player) e.getPlayer();
        UUID u = p.getUniqueId();
        if (manager.openMain.remove(u)) {
            Inventory inv = e.getInventory();
            for (int i = 0; i < 45; i++) {
                ItemStack it = inv.getItem(i);
                if (it != null && it.getType() != Material.AIR) {
                    giveBack(p, it);
                    inv.setItem(i, null);
                }
            }
        }
        manager.openMultipliers.remove(u);
        manager.openListPage.remove(u);
    }

    @EventHandler
    public void onChat(AsyncChatEvent e) {
        Player p = e.getPlayer();
        UUID u = p.getUniqueId();
        if (!manager.waitingSearch.remove(u)) return;
        e.setCancelled(true);
        String msg = PlainTextComponentSerializer.plainText().serialize(e.message());
        Bukkit.getScheduler().runTask(KratosPlugin.getInstance(), () -> {
            if (msg.equalsIgnoreCase("iptal")) {
                manager.openListMenu(p, 1);
            } else {
                manager.performSearch(p, msg);
            }
        });
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID u = e.getPlayer().getUniqueId();
        manager.openMain.remove(u);
        manager.openMultipliers.remove(u);
        manager.openListPage.remove(u);
        manager.waitingSearch.remove(u);
    }

    private void giveBack(Player p, ItemStack it) {
        p.getInventory().addItem(it).values().forEach(rem -> p.getWorld().dropItemNaturally(p.getLocation(), rem));
    }
}
