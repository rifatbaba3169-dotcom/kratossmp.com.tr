package com.kratossmp.plugin;

import com.kratossmp.plugin.commands.*;
import com.kratossmp.plugin.listeners.*;
import com.kratossmp.plugin.managers.*;
import com.kratossmp.plugin.tasks.*;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

public final class KratosPlugin extends JavaPlugin {

    private static KratosPlugin instance;
    private Economy economy;
    private KitManager kitManager;
    private KratosToolManager toolManager;
    private SellManager sellManager;
    private OnlineRewardTask rewardTask;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        setupEconomy();

        this.kitManager = new KitManager(this);
        this.toolManager = new KratosToolManager(this);
        this.sellManager = new SellManager(this);

        // Komutlar
        if (getCommand("discord") != null) getCommand("discord").setExecutor(new DiscordCommand());
        if (getCommand("duyuru") != null) getCommand("duyuru").setExecutor(new DuyuruCommand());
        if (getCommand("event") != null) getCommand("event").setExecutor(new EventCommand());

        TpaCommand tpaCmd = new TpaCommand();
        for (String cmd : new String[]{"tpa", "tpahere", "tpauto", "tpahereauto", "tpaoff", "tpaon"}) {
            if (getCommand(cmd) != null) getCommand(cmd).setExecutor(tpaCmd);
        }

        KitCommand kitCmd = new KitCommand(kitManager);
        for (String cmd : new String[]{"kit", "kitolustur", "kitsil", "kitduzelt", "adminkitolustur"}) {
            if (getCommand(cmd) != null) getCommand(cmd).setExecutor(kitCmd);
        }

        if (getCommand("kratosalet") != null) getCommand("kratosalet").setExecutor(new KratosToolCommand(toolManager));

        SellCommand sellCmd = new SellCommand(sellManager);
        if (getCommand("sell") != null) getCommand("sell").setExecutor(sellCmd);
        if (getCommand("sellfiyat") != null) getCommand("sellfiyat").setExecutor(sellCmd);

        this.rewardTask = new OnlineRewardTask(this);
        this.rewardTask.runTaskTimer(this, 20L, 20L);
        if (getCommand("surem") != null) getCommand("surem").setExecutor(new SuremCommand(rewardTask));

        // Dinleyiciler
        getServer().getPluginManager().registerEvents(new ExplosionDamageListener(this), this);
        getServer().getPluginManager().registerEvents(new KitListener(kitManager), this);
        getServer().getPluginManager().registerEvents(new KratosToolListener(toolManager), this);
        getServer().getPluginManager().registerEvents(new SellListener(sellManager), this);

        // Kratos Aletleri Saniye Sayacı (Optimize)
        Bukkit.getScheduler().runTaskTimer(this, () -> toolManager.tickHeldTools(), 20L, 20L);

        getLogger().info("KratosPlugin tum sistemleriyle aktif edildi! (Purpur 1.21.5 - Java 21)");
    }

    @Override
    public void onDisable() {
        if (kitManager != null) kitManager.saveKits();
        if (toolManager != null) toolManager.saveData();
        if (sellManager != null) sellManager.saveData();
        getLogger().info("KratosPlugin verileri kaydedildi ve kapatildi.");
        instance = null;
    }

    private void setupEconomy() {
        if (getServer().getPluginManager().getPlugin("Vault") == null) return;
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp != null) economy = rsp.getProvider();
    }

    public static KratosPlugin getInstance() { return instance; }
    public Economy getEconomy() { return economy; }
    public KitManager getKitManager() { return kitManager; }
    public KratosToolManager getToolManager() { return toolManager; }
    public SellManager getSellManager() { return sellManager; }
}
