package com.kratossmp.plugin.listeners;

import com.kratossmp.plugin.KratosPlugin;
import org.bukkit.entity.EndCrystal;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;

public class ExplosionDamageListener implements Listener {
    private final KratosPlugin plugin;

    public ExplosionDamageListener(KratosPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof EndCrystal && event.getCause() == EntityDamageEvent.DamageCause.ENTITY_EXPLOSION) {
            double kristalCarpan = plugin.getConfig().getDouble("explosion.kristal-carpan", 3.0);
            event.setDamage(event.getDamage() * kristalCarpan);
        }
    }

    @EventHandler
    public void onDamage(EntityDamageEvent event) {
        if (event.getCause() == EntityDamageEvent.DamageCause.BLOCK_EXPLOSION) {
            double capaCarpan = plugin.getConfig().getDouble("explosion.capa-carpan", 3.0);
            event.setDamage(event.getDamage() * capaCarpan);
        }
    }
}
