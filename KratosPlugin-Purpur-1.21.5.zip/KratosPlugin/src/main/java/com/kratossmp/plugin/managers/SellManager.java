package com.kratossmp.plugin.managers;

import com.kratossmp.plugin.KratosPlugin;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.util.*;

public class SellManager {
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();
    private final KratosPlugin plugin;
    private final File file;
    private YamlConfiguration data;

    private final Map<Material, Double> priceMap = new LinkedHashMap<>();
    private final List<Material> sellableList = new ArrayList<>();
    private final Map<String, String> trDict = new HashMap<>();

    public final Set<UUID> openMain = new HashSet<>();
    public final Set<UUID> openMultipliers = new HashSet<>();
    public final Map<UUID, Integer> openListPage = new HashMap<>();
    public final Map<UUID, String> searchQuery = new HashMap<>();
    public final Map<UUID, List<Material>> searchResults = new HashMap<>();
    public final Set<UUID> waitingSearch = new HashSet<>();

    public SellManager(KratosPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "sell_prices.yml");
        loadPrices();
        initTrDict();
    }

    public void saveData() {
        try { if (data != null) data.save(file); } catch (IOException ignored) {}
    }

    public void loadPrices() {
        priceMap.clear();
        sellableList.clear();

        if (!file.exists()) {
            data = new YamlConfiguration();
            populateDefaults();
            saveData();
        } else {
            data = YamlConfiguration.loadConfiguration(file);
        }

        if (data.getConfigurationSection("prices") != null) {
            for (String key : data.getConfigurationSection("prices").getKeys(false)) {
                Material mat = Material.getMaterial(key.toUpperCase(Locale.ROOT));
                double price = data.getDouble("prices." + key, 0);
                if (mat != null && price > 0) {
                    priceMap.put(mat, price);
                    sellableList.add(mat);
                }
            }
        }
    }

    private void populateDefaults() {
        String[] raw = {
            "NETHERITE_BLOCK;1000000", "NETHERITE_INGOT;100000", "NETHERITE_SCRAP;90000", "ANCIENT_DEBRIS;50000",
            "DIAMOND_BLOCK;4500", "DIAMOND;500", "EMERALD_BLOCK;3600", "EMERALD;400", "GOLD_BLOCK;2250",
            "GOLD_INGOT;250", "IRON_BLOCK;1350", "IRON_INGOT;150", "LAPIS_LAZULI;120", "COPPER_BLOCK;900",
            "COPPER_INGOT;100", "REDSTONE_BLOCK;900", "REDSTONE;100", "COAL_BLOCK;900", "COAL;100",
            "GHAST_TEAR;100", "PHANTOM_MEMBRANE;30", "GUNPOWDER;10", "SLIME_BALL;10", "LEATHER;8",
            "SPIDER_EYE;8", "BONE;5", "BONE_BLOCK;45", "ROTTEN_FLESH;5", "BEEF;5", "STRING;5",
            "INK_SAC;5", "FEATHER;4", "ARROW;10", "SUGAR_CANE;30", "KELP;25", "DRIED_KELP_BLOCK;30",
            "DRIED_KELP;3", "BAMBOO;6", "CACTUS;6", "PUMPKIN;8", "MELON;18", "MELON_SLICE;2",
            "WHEAT;4", "HAY_BLOCK;36", "BEETROOT;4", "GLOW_BERRIES;3", "COCOA_BEANS;4", "HONEYCOMB;8",
            "HONEY_BOTTLE;10", "EGG;2", "SEA_PICKLE;6", "CHORUS_FRUIT;5", "RED_MUSHROOM;4",
            "BROWN_MUSHROOM;4", "SUGAR;5", "WHEAT_SEEDS;1", "OAK_LOG;25", "SPRUCE_LOG;25", "BIRCH_LOG;50",
            "JUNGLE_LOG;25", "ACACIA_LOG;25", "DARK_OAK_LOG;25", "MANGROVE_LOG;25", "CHERRY_LOG;50",
            "OBSIDIAN;100", "END_CRYSTAL;200", "CRYING_OBSIDIAN;75", "GLOWSTONE;100", "TOTEM_OF_UNDYING;625",
            "ENDER_PEARL;50", "GOLDEN_APPLE;100", "EXPERIENCE_BOTTLE;12", "FIREWORK_ROCKET;7",
            "NETHER_STAR;500000", "BEACON;495000", "ELYTRA;1000000", "DRAGON_EGG;15000000", "TRIDENT;300000",
            "SHULKER_SHELL;20000", "BLAZE_ROD;300", "MAGMA_CREAM;150", "COBBLESTONE;2", "STONE;3",
            "DIRT;2", "GRASS_BLOCK;4", "SAND;3", "GRAVEL;3", "NETHERRACK;2", "END_STONE;5"
        };
        for (String s : raw) {
            String[] p = s.split(";");
            data.set("prices." + p[0], Double.parseDouble(p[1]));
        }
    }

    private void initTrDict() {
        String[] dict = {
            "elmas=diamond", "demir=iron", "altin=gold", "zumrut=emerald", "komur=coal", "bakir=copper",
            "netherit=netherite", "odun=log", "kutuk=log", "tahta=planks", "tas=stone", "kum=sand",
            "toprak=dirt", "cakil=gravel", "cam=glass", "yun=wool", "kemik=bone", "ip=string",
            "ok=arrow", "seker=sugar", "bambu=bamboo", "kelp=kelp", "obsidyen=obsidian", "inci=pearl"
        };
        for (String d : dict) {
            String[] p = d.split("=");
            trDict.put(p[0], p[1]);
        }
    }

    public int getSellableCount() { return sellableList.size(); }

    public double getPrice(ItemStack it) {
        if (it == null || it.getType() == Material.AIR) return 0;
        if (it.hasItemMeta() && it.getItemMeta().hasDisplayName()) return 0;
        return priceMap.getOrDefault(it.getType(), 0.0);
    }

    public String getMultiplierKey(Material m) {
        return switch (m) {
            case BONE -> "Kemik";
            case ARROW -> "Ok";
            case KELP -> "Kelp";
            case SUGAR_CANE -> "Şeker Kamışı";
            case BAMBOO -> "Bambu";
            case SEA_PICKLE -> "Deniz Turşusu";
            default -> "";
        };
    }

    private void checkDayReset(UUID u) {
        String today = LocalDate.now().toString();
        String saved = data.getString("players." + u + ".day", "");
        if (!today.equals(saved)) {
            data.set("players." + u + ".counts", null);
            data.set("players." + u + ".day", today);
        }
    }

    public int getTodayCount(UUID u, String key) {
        checkDayReset(u);
        return data.getInt("players." + u + ".counts." + key, 0);
    }

    private int getThreshold(int level) {
        int ilk = plugin.getConfig().getInt("sell.carpan-ilk", 100);
        int ek = plugin.getConfig().getInt("sell.carpan-ek", 50);
        return (level * ilk) + (ek * level * (level - 1) / 2);
    }

    public int getLevel(int count) {
        int maxLvl = plugin.getConfig().getInt("sell.carpan-seviye", 20);
        int n = 0;
        while (n < maxLvl) {
            if (getThreshold(n + 1) > count) return n;
            n++;
        }
        return n;
    }

    public double getMultiplier(UUID u, String key) {
        int lvl = getLevel(getTodayCount(u, key));
        return Math.round((1.0 + (0.1 * lvl)) * 10.0) / 10.0;
    }

    public double sellWithMultiplier(UUID u, String key, double basePrice, int amount) {
        int c = getTodayCount(u, key);
        int left = amount;
        double total = 0;
        int maxLvl = plugin.getConfig().getInt("sell.carpan-seviye", 20);

        while (left > 0) {
            int n = getLevel(c);
            double m = 1.0 + (0.1 * n);
            int take = (n >= maxLvl) ? left : Math.min(left, getThreshold(n + 1) - c);
            total += basePrice * m * take;
            c += take;
            left -= take;
        }
        data.set("players." + u + ".counts." + key, c);
        saveData();
        return total;
    }

    public void openSellMenu(Player p) {
        Inventory inv = Bukkit.createInventory(null, 54, LEGACY.deserialize("&6&lEşya Sat"));
        ItemStack gray = pane(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 45; i < 54; i++) inv.setItem(i, gray);

        inv.setItem(45, button(Material.CLOCK, "&e&lÇarpanlar", "&7Bugünkü satış çarpanlarını gör.", "&8Her gün sıfırlanır."));
        inv.setItem(48, button(Material.LIME_STAINED_GLASS_PANE, "&a&lKABUL ET", "&7Koyduğun eşyaları satar."));
        inv.setItem(50, button(Material.RED_STAINED_GLASS_PANE, "&c&lREDDET", "&7Satışı iptal eder, eşyaların geri verilir."));
        inv.setItem(53, button(Material.BOOK, "&e&lSatılabilirler", "&7Satılabilecek eşyaları ve fiyatlarını gör."));

        openMain.add(p.getUniqueId());
        p.openInventory(inv);
    }

    public void openMultiplierMenu(Player p) {
        Inventory inv = Bukkit.createInventory(null, 54, LEGACY.deserialize("&6&lÇarpanlar"));
        ItemStack gray = pane(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < 54; i++) inv.setItem(i, gray);

        putMultItem(inv, 19, Material.BONE, "Kemik", p.getUniqueId());
        putMultItem(inv, 20, Material.ARROW, "Ok", p.getUniqueId());
        putMultItem(inv, 21, Material.KELP, "Kelp", p.getUniqueId());
        putMultItem(inv, 23, Material.SUGAR_CANE, "Şeker Kamışı", p.getUniqueId());
        putMultItem(inv, 24, Material.BAMBOO, "Bambu", p.getUniqueId());
        putMultItem(inv, 25, Material.SEA_PICKLE, "Deniz Turşusu", p.getUniqueId());
        inv.setItem(49, button(Material.BARRIER, "&c&lGeri"));

        openMultipliers.add(p.getUniqueId());
        p.openInventory(inv);
    }

    private void putMultItem(Inventory inv, int slot, Material m, String key, UUID u) {
        int c = getTodayCount(u, key);
        int n = getLevel(c);
        double mult = getMultiplier(u, key);
        int maxLvl = plugin.getConfig().getInt("sell.carpan-seviye", 20);
        List<Component> lore = new ArrayList<>();
        lore.add(LEGACY.deserialize("&7Şu anki çarpan: &e" + mult + "x"));
        lore.add(LEGACY.deserialize("&7Bugün satılan: &f" + c + " adet"));
        if (n >= maxLvl) {
            lore.add(LEGACY.deserialize("&a&lEn yüksek çarpana ulaştın!"));
        } else {
            double nextM = Math.round((1.0 + (0.1 * (n + 1))) * 10.0) / 10.0;
            int rem = getThreshold(n + 1) - c;
            lore.add(LEGACY.deserialize("&7" + nextM + "x için: &f" + rem + " adet daha"));
        }
        lore.add(LEGACY.deserialize("&8Çarpanlar her gün sıfırlanır."));
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(LEGACY.deserialize("&e&l" + key));
        meta.lore(lore);
        it.setItemMeta(meta);
        inv.setItem(slot, it);
    }

    public void openListMenu(Player p, int page) {
        UUID u = p.getUniqueId();
        String q = searchQuery.getOrDefault(u, "");
        List<Material> list = q.isEmpty() ? sellableList : searchResults.getOrDefault(u, Collections.emptyList());

        int pages = Math.max(1, (int) Math.ceil(list.size() / 45.0));
        page = Math.max(1, Math.min(page, pages));
        openListPage.put(u, page);

        String title = q.isEmpty() ? "&6&lSatılabilirler &7(Sayfa " + page + ")" : "&6&lSatılabilirler &7- &f" + q + " &7(" + page + ")";
        Inventory inv = Bukkit.createInventory(null, 54, LEGACY.deserialize(title));

        for (int i = 0; i < 45; i++) {
            int idx = ((page - 1) * 45) + i;
            if (idx >= list.size()) break;
            Material m = list.get(idx);
            double pr = priceMap.getOrDefault(m, 0.0);
            ItemStack it = new ItemStack(m);
            ItemMeta meta = it.getItemMeta();
            meta.lore(Collections.singletonList(LEGACY.deserialize("&7Fiyat (1 adet): &a" + pr)));
            it.setItemMeta(meta);
            inv.setItem(i, it);
        }

        ItemStack gray = pane(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 45; i < 54; i++) inv.setItem(i, gray);
        if (page > 1) inv.setItem(45, button(Material.ARROW, "&e« Önceki Sayfa"));
        if (!q.isEmpty()) inv.setItem(46, button(Material.HOPPER, "&e&lAramayı Temizle"));
        inv.setItem(48, button(Material.BARRIER, "&c&lGeri"));
        inv.setItem(49, button(Material.PAPER, "&6Sayfa &f" + page + "&7/&f" + pages));
        inv.setItem(50, button(Material.COMPASS, "&b&lEşya Ara", "&7Tıkla, sonra sohbete eşya adını yaz."));
        if (page < pages) inv.setItem(53, button(Material.ARROW, "&eSonraki Sayfa »"));

        p.openInventory(inv);
    }

    public void performSearch(Player p, String query) {
        UUID u = p.getUniqueId();
        String norm = query.toLowerCase(Locale.ROOT)
                .replace("ı", "i").replace("ş", "s").replace("ğ", "g")
                .replace("ü", "u").replace("ö", "o").replace("ç", "c");
        String[] words = norm.split("\\s+");
        List<String> kw = new ArrayList<>();
        for (String w : words) {
            if (w.isEmpty()) continue;
            kw.add(trDict.getOrDefault(w, w));
        }
        List<Material> matches = new ArrayList<>();
        for (Material m : sellableList) {
            String mn = m.name().toLowerCase(Locale.ROOT).replace("_", " ");
            boolean ok = true;
            for (String k : kw) {
                if (!mn.contains(k)) { ok = false; break; }
            }
            if (ok) matches.add(m);
        }
        String disp = String.join(" ", kw);
        if (matches.isEmpty()) {
            p.sendMessage(LEGACY.deserialize("&c'" + disp + "' için sonuç bulunamadı."));
            searchQuery.remove(u);
            searchResults.remove(u);
            openListMenu(p, 1);
            return;
        }
        searchQuery.put(u, disp);
        searchResults.put(u, matches);
        p.sendMessage(LEGACY.deserialize("&a'" + disp + "' için &e" + matches.size() + " &asonuç bulundu."));
        openListMenu(p, 1);
    }

    private ItemStack pane(Material m, String name) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(Component.text(name));
        it.setItemMeta(meta);
        return it;
    }

    private ItemStack button(Material m, String name, String... loreLines) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(LEGACY.deserialize(name));
        if (loreLines.length > 0) {
            List<Component> lore = new ArrayList<>();
            for (String l : loreLines) lore.add(LEGACY.deserialize(l));
            meta.lore(lore);
        }
        it.setItemMeta(meta);
        return it;
    }
}
